from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

def extract_numeric_part(price_string):
    # Extract numeric part from the string (assuming the format is 'XXXX.XX')
    numeric_part = ''.join(c for c in price_string if c.isdigit() or c == '.')
    return numeric_part

def get_product_info(product_name):
    api_url = "https://ihaha.rw/shop/?product_cat=&s=&post_type=product"

    # Simulate searching for the product on www.ihaha.rw
    response = requests.get(api_url, params={"s": product_name})

    if response.status_code == 200:
        # Parse HTML content with BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')

        # Extract product information from HTML
        product_list = []

        # Find all product containers
        product_containers = soup.find_all('div', class_='product-block-inner')

        for product_container in product_containers:
            product_info = {
                'product_name': product_container.find('h3', class_='product-name').text.strip() if product_container.find('h3', class_='product-name') else 'No Result!',
                'product_price': float(extract_numeric_part(product_container.find('span', class_='woocommerce-Price-amount').text.strip())) if product_container.find('span', class_='woocommerce-Price-amount') else 0.0,
                'global_rating': float(product_container.find('span', class_='star-rating')['title']) if product_container.find('span', class_='star-rating') else 0.0,
                'retailer_name': product_container.find('div', class_='product-brand').text.strip() if product_container.find('div', class_='product-brand') else 'Not available!',
                'retailer_email': product_container.find('div', class_='product-brand').text.strip() if product_container.find('div', class_='product-brand') else 'Not available!',
                'product_picture_name': product_container.find('div', class_='image-block').find('img')['data-src'] if product_container.find('div', class_='image-block') else 'No Result!',
                # Add more extraction logic for other product details
            }
            product_list.append(product_info)

        return product_list
    else:
        return None

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        product_name = request.form['product_name']
        product_info = get_product_info(product_name)

        if product_info:
            return render_template('result.html', product_info=product_info)
        else:
            return render_template('result.html', error="Product not found")

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
